
let DATA = new PouchDB("questions");
DATA.bulkDocs([
  {
    _id : "1",
    question : "A perfectly competitive market has",
    answers : {
      A : "Firms that set their own prices.",
      B : "Only one seller.",
      C : "At least a few sellers.",
      D : "Many buyers and sellers."},
    correct : "D"
  },
  {
    _id : "2",
    question : "The law of demand states that an increase in the price of a good",
    answers : {
      A : "Increases the supply of that good.",
      B : "Decreases the quantity demanded for that good along its demand curve.",
      C : "Decreases the demand for that good.",
      D : "Increases the quantity supplied of that good along its supply curve."},
    correct : "A"
  },
  {
    _id : "3",
    question : "The law of supply states that an increase in the price of a good",
    answers : {
      A : "increases the quantity supplied of that good along its supply curve.",
      B : "increases the supply of that good.",
      C : "decreases the demand for that good.",
      D : "decreases the quantity demanded for that good along its demand curve."},
    correct : "A"
  },
  {
    _id : "4",
    question : "If an increase in consumer incomes leads to a decrease in the demand for camping equipment, then camping equipment is",
    answers : {
      A : "a normal good.",
      B : "an inferior good.",
      C : "a substitute good.",
      D : "a complementary good."},
    correct : "B"
  },
  {
    _id : "5",
    question : "That the supply curve for ice cream cones is upward sloping indicates that",
    answers : {
      A : "the marginal cost of providing ice cream cones increases as more cones are produced.",
      B : "as the price of ice cream cones increases, the production technology is upgraded.",
      C : "as the price increases, the opportunity cost of making ice cream cones decreases.",
      D : "all of the above."},
    correct : "A"
  },
  {
    _id : "6",
    question : "Which of the following shifts the demand for watches to the right?",
    answers : {
      A : "an increase in the price of watches",
      B : "a decrease in the price of watch batteries if watch batteries and watches are complements",
      C : "a decrease in consumer incomes if watches are a normal good",
      D : "a decrease in the price of watches"},
    correct : "B"
  },
  {
    _id : "7",
    question : "If the price of a good is above the equilibrium price,",
    answers : {
      A : "there is a surplus (i.e. an excess supply) and the price will rise.",
      B : "there is a shortage (i.e. an excess demand) and the price will fall.",
      C : "there is a shortage (i.e. an excess demand) and the price will rise.",
      D : "there is a surplus (i.e. an excess supply) and the price will fall."},
    correct : "D"
  },
  {
    _id : "8",
    question : "Suppose there is an increase in both the supply and demand for personal computers. In the market for personal computers, we would expect",
    answers : {
      A : "the equilibrium quantity to rise and the equilibrium price to rise.",
      B : "the equilibrium quantity to rise and the equilibrium price to fall.",
      C : "the change in the equilibrium quantity to be ambiguous and the equilibrium price to rise.",
      D : "the equilibrium quantity to rise and the change in the equilibrium price to be ambiguous."},
    correct : "D"
  },
  {
    _id : "9",
    question : "A decrease (leftward shift) in the supply for a good will tend to cause",
    answers : {
      A : "an increase in the equilibrium price and quantity.",
      B : "a decrease in the equilibrium price and an increase in the equilibrium quantity.",
      C : "a decrease in the equilibrium price and quantity.",
      D : "an increase in the equilibrium price and a decrease in the equilibrium quantity."},
    correct : "D"
  }, 
  {
    _id : "10",
    question : "Suppose both buyers and sellers of wheat expect the price of wheat to rise in the near future. What would we expect to happen to the equilibrium price and quantity in the market for wheat today?",
    answers : {
      A : "The impact on both price and quantity is ambiguous.",
      B : "Price will increase; quantity will increase.",
      C : "Price will increase; quantity is ambiguous.",
      D : "Price will increase; quantity will decrease."},
    correct : "C"
  }
]);

let questionIndex;
let playerScore;
let allQuestions = [];
loadQuestions();

function loadQuestions() {
  DATA.allDocs({include_docs: true}, function(err, doc) {
  doc.rows.forEach(function (row) {
    allQuestions.push(row.doc);
  })})
}

function refreshScreen() {
  document.body.innerHTML = "";
  renderHeader();
  renderQuestionNum();
  renderScore();
}

function renderHeader() {
  document.body.insertAdjacentHTML("afterbegin", "<h1>Supply and Demand Quiz</h1>");
}

function renderScore() {
  document.body.insertAdjacentHTML("beforeend", `<p>Score: ${playerScore}/10</p>`);
}

function renderQuestionNum() {
  document.body.insertAdjacentHTML("beforeend", `<p>Question Number: ${questionIndex+1}/10</p>`);
}

function renderStartScreen() {
  questionIndex = 0;
  playerScore = 0;
  document.body.innerHTML = "";
  renderHeader();
  const start = `
  <section id="start-screen">
    <p>Take this quick 10 question quiz to test your understanding of supply and demand theory!</p>
    <p>Click down below when you're ready to start.</p>
    <button onclick="startQuiz()" id="js-start-button">Start</button>
  </section>`;
  document.body.insertAdjacentHTML("beforeend", start);
}

function startQuiz() {
  questionIndex = 0;
  playerScore = 0;
  renderQuestionScreen(questionIndex);
}

function getQuestionObj(index) {
  return allQuestions[index];
}

function getAnswers(question) {
  return Object.values(question["answers"]);
}

function getQuestionText(question) {
  return question["question"];
}

function getCorrectAnswer(question) {
  return question["correct"];
}

function generateQuestion(index) {
  const question = getQuestionObj(index);
  const answers = getAnswers(question);
  return `
  <h3>${getQuestionText(question)}</h3>
  <form>
    <fieldset>
    <label for="A" class="answerOption">A</label>
    <input type="radio" id="A" class="answerChoice" name="answer" required value="A">${answers[0]}<br>
    <label for="B" class="answerOption">B</label>
    <input type="radio" id="B" class="answerChoice" name="answer" value="B">${answers[1]}<br>
    <label for="C" class="answerOption">C</label>
    <input type="radio" id="C" class="answerChoice" name="answer" value="C">${answers[2]}<br>
    <label for="D" class="answerOption">D</label>
    <input type="radio" id="D" class="answerChoice" name="answer" value="D">${answers[3]}<br>
    <input type="submit" class="submitAnswer" onclick="validateAnswer(event)">
    </fieldset>
  </form>`;
}

function disableSubmit() {
  document.getElementsByClassName("submitAnswer")[0].setAttribute("disabled", "true");
}

function enableSubmit() {
  document.getElementsByClassName("submitAnswer")[0].setAttribute("disabled", "false");
}

function getChoice() {
  if (document.querySelector("input[name='answer']:checked") !== null) {
    return document.querySelector("input[name='answer']:checked").getAttribute("id");
  }
}

function renderQuestionScreen() {
  refreshScreen();
  document.body.insertAdjacentHTML("beforeend", generateQuestion(questionIndex));
}

function validateAnswer(event) {
  event.preventDefault();
  disableSubmit();
  const playerChoice = getChoice();
  const question = getQuestionObj(questionIndex);
  questionIndex++;
  if (playerChoice === getCorrectAnswer(question)) {
    playerScore++;
    renderCorrect();
  } else {
    renderIncorrect(getCorrectAnswer(question));
  }
}

function nextQuestionButton() {
  const button = `<input type="button" onclick="nextQuestion()" class="js-next-button" value="Next">`;
  document.body.insertAdjacentHTML("beforeend", button);
}

function renderCorrect() {
  const message = `
  <section id="questionMessage">
  <h3>Correct!</h3>
  </section>`;
  document.body.insertAdjacentHTML("beforeend", message)
  nextQuestionButton();
}

function renderIncorrect(correctAnswer) {
  const message = `
  <section id="questionMessage">
  <h3>Sorry!</h3>
  <p>The correct answer was: ${correctAnswer}</p>
  </section>`;
  document.body.insertAdjacentHTML("beforeend", message);
  nextQuestionButton();
}

function nextQuestion() {
  enableSubmit();
  if (questionIndex === allQuestions.length) {
    console.log("end of quiz. go home");
    renderEndScreen();
  } else {
    renderQuestionScreen();
  }
}

function renderEndScreen() {
  document.body.innerHTML = "";
  renderHeader();
  renderScore();
  let message = `
  <h3>That's the end of the quiz!</h3>
  <input type="button" onclick="renderStartScreen()" value="Back to Home">`;
  document.body.insertAdjacentHTML("beforeend", message);
}
